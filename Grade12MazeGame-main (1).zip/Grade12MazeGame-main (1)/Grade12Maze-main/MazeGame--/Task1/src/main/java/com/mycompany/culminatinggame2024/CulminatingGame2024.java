/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.culminatinggame2024;


/**
 *
 * @author alexa
 */
public class CulminatingGame2024 {

    static Logic logic = new Logic();
    
    public static void main(String[] args) {
        
        logic.start();
        
    }
}
